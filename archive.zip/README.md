# 7thProject
A melee combat game with open world environment
